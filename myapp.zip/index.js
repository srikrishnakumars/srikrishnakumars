const express = require('express');
const AWS = require('aws-sdk');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Configure AWS SDK
AWS.config.update({
    region: 'ap-south-1',
    accessKeyId: 'AKIAS4FI32KESQJH324U',
    secretAccessKey: 'xoOkP4/xtSyhOoXsRzL6YkkHiAUQziiLQzJh0KUf'
});
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const tableName = 'UserTable'; // Name of your DynamoDB table

app.use(bodyParser.json());

// Frontend HTML content
const frontendHTML = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
</head>
<body>
    <form id="userForm">
 <!--       <label for="sskk">SSKK:</label> -->
     <!--   <input type="text" id="sskk" name="sskk" required><br><br> -->
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br><br>
        <label for="mobile">Mobile Number:</label>
        <input type="text" id="mobile" name="mobile" required><br><br>
        <button type="submit">Submit</button>
    </form>

    <script>
        document.getElementById('userForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(this);
            const userData = {
                sskk: formData.get('sskk'),
                name: formData.get('name'),
                mobile: formData.get('mobile')
            };
            fetch('/api/user', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            })
            .then(response => response.json())
            .then(data => {
                console.log('User data saved:', data);
                // Optionally, show a success message or redirect the user
            })
            .catch(error => {
                console.error('Error saving user data:', error);
                // Handle errors
            });
        });
    </script>
</body>
</html>
`;

// API endpoint to save user data
app.post('/api/user', (req, res) => {
    const { sskk, name, mobile } = req.body;
    const params = {
        TableName: tableName,
        Item: {
            sskk, // Adding the partition key 'sskk'
            name,
            mobile
        }
    };
    dynamoDB.put(params, (error, data) => {
        if (error) {
            console.error('Unable to add item. Error JSON:', JSON.stringify(error, null, 2));
            res.status(500).json({ error: 'Unable to save user data' });
        } else {
            console.log('User data saved:', JSON.stringify(data, null, 2));
            res.json({ message: 'User data saved successfully' });
        }
    });
});

// Serve frontend HTML
app.get('/', (req, res) => {
    res.send(frontendHTML);
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
